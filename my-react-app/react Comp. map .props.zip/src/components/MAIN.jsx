import "../ComCss/main.css"
let MAIN = (props) => {
    return (
        <>
            <div className="main">
                <h1>{props.title}</h1>
                
                <p>{props.discription}</p>
            </div>
        </>
    )
}

export default MAIN