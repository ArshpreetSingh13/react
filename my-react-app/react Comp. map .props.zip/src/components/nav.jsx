import "./nav.css"
const NavBar=()=>{
    return(
        <>
        <div>
            <nav>
                    <ul>
                        <li>Home</li>
                        <li>About</li>
                        <li>Contact</li>
                    </ul>
            </nav>
        </div>

        </>
    )
}

export default NavBar