import "../ComCss/footer.css"
const Footer=()=>{

    return(
        <div className="footer">
            <p>Copyright &copy; By Arshpreet singh</p>
        </div>
    )

}

export default Footer